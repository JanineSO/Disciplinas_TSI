You can choose where to place a certain diagram by using `![name](<diagram name>.puml)`

![ditaa](ditaa.puml)

Feel free to add any additional details necesary.
